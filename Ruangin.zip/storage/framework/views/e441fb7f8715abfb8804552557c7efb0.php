<!-- Admin Navigation -->
<div style="display: flex; gap: 2rem; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 2px solid rgba(148,163,184,0.3);">
    <a href="<?php echo e(route('admin.dashboard')); ?>" 
       style="display: inline-flex; align-items: center; gap: 0.5rem; padding-bottom: 0.75rem; color: #cbd5f5; text-decoration: none; font-weight: 600; font-size: 0.95rem; transition: all 0.3s ease; border-bottom: 3px solid <?php echo e(request()->routeIs('admin.dashboard') ? '#22d3ee' : 'transparent'); ?>; <?php echo e(request()->routeIs('admin.dashboard') ? 'color: #22d3ee;' : ''); ?>">
        📊 Dashboard
    </a>
    <a href="<?php echo e(route('admin.ruangan.index')); ?>" 
       style="display: inline-flex; align-items: center; gap: 0.5rem; padding-bottom: 0.75rem; color: #cbd5f5; text-decoration: none; font-weight: 600; font-size: 0.95rem; transition: all 0.3s ease; border-bottom: 3px solid <?php echo e(request()->routeIs('admin.ruangan.*') ? '#22d3ee' : 'transparent'); ?>; <?php echo e(request()->routeIs('admin.ruangan.*') ? 'color: #22d3ee;' : ''); ?>">
        🏛️ Ruangan
    </a>
    <a href="<?php echo e(route('admin.booking.index')); ?>" 
       style="display: inline-flex; align-items: center; gap: 0.5rem; padding-bottom: 0.75rem; color: #cbd5f5; text-decoration: none; font-weight: 600; font-size: 0.95rem; transition: all 0.3s ease; border-bottom: 3px solid <?php echo e(request()->routeIs('admin.booking.*') ? '#22d3ee' : 'transparent'); ?>; <?php echo e(request()->routeIs('admin.booking.*') ? 'color: #22d3ee;' : ''); ?>">
        📋 Booking
    </a>
    <a href="<?php echo e(route('admin.user.index')); ?>" 
       style="display: inline-flex; align-items: center; gap: 0.5rem; padding-bottom: 0.75rem; color: #cbd5f5; text-decoration: none; font-weight: 600; font-size: 0.95rem; transition: all 0.3s ease; border-bottom: 3px solid <?php echo e(request()->routeIs('admin.user.*') ? '#22d3ee' : 'transparent'); ?>; <?php echo e(request()->routeIs('admin.user.*') ? 'color: #22d3ee;' : ''); ?>">
        👥 User
    </a>
    <a href="<?php echo e(route('admin.laporan.index')); ?>" 
       style="display: inline-flex; align-items: center; gap: 0.5rem; padding-bottom: 0.75rem; color: #cbd5f5; text-decoration: none; font-weight: 600; font-size: 0.95rem; transition: all 0.3s ease; border-bottom: 3px solid <?php echo e(request()->routeIs('admin.laporan.*') ? '#22d3ee' : 'transparent'); ?>; <?php echo e(request()->routeIs('admin.laporan.*') ? 'color: #22d3ee;' : ''); ?>">
        📈 Laporan
    </a>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\Ruangin\resources\views/admin/partials/navigation.blade.php ENDPATH**/ ?>