<?php $__env->startSection('title', 'Registrasi - Ruangin.app'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .auth-wrapper {
        min-height: calc(100vh - 140px);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .auth-card {
        max-width: 520px;
        width: 100%;
        border-radius: 28px;
        background:
            radial-gradient(circle at top left, rgba(129,140,248,0.3), transparent 60%),
            radial-gradient(circle at bottom right, rgba(56,189,248,0.4), transparent 60%),
            rgba(15,23,42,0.96);
        border: 1px solid rgba(148,163,184,0.5);
        box-shadow: 0 24px 60px rgba(15,23,42,0.95);
        color: #e5e7eb;
        padding: 2.2rem 2.4rem 2rem;
        position: relative;
        overflow: hidden;
        animation: fadeInUp .45s ease-out;
    }

    .auth-card::before {
        content: "";
        position: absolute;
        inset: 0;
        background: radial-gradient(circle at 0 0, rgba(255,255,255,0.35), transparent 65%);
        opacity: .12;
        pointer-events: none;
    }

    .auth-card-inner {
        position: relative;
        z-index: 1;
    }

    .auth-badge {
        text-transform: uppercase;
        letter-spacing: .14em;
        font-size: .78rem;
        color: #cbd5f5;
        text-align: center;
    }

    .auth-title {
        font-size: 1.8rem;
        font-weight: 800;
        margin-bottom: .4rem;
        background: linear-gradient(120deg, #e5e7eb, #c4b5fd, #22d3ee);
        -webkit-background-clip: text;
        color: transparent;
        text-align: center;
    }

    .auth-subtitle {
        font-size: .9rem;
        color: #e5e7eb;
        text-align: center;
        margin-bottom: 1.4rem;
    }

    .auth-card .form-label {
        color: #e5e7eb;
        font-weight: 600;
        font-size: .9rem;
    }

    .auth-card .form-control,
    .auth-card .form-select {
        background: rgba(15,23,42,0.9);
        border-color: rgba(148,163,184,0.7);
        color: #f9fafb;
    }

    .auth-card .form-control::placeholder {
        color: #9ca3af;
    }

    .auth-footer-text {
        font-size: .85rem;
        color: #cbd5f5;
    }

    .auth-link {
        color: #7dd3fc;
        text-decoration: none;
        font-weight: 500;
    }

    .auth-link:hover {
        text-decoration: underline;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(16px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-card-inner">

            <div class="mb-3">
                <div class="auth-badge mb-2">Buat Akun Baru</div>
                <h1 class="auth-title">Registrasi</h1>
                <p class="auth-subtitle">
                    Daftarkan akun Anda sebagai mahasiswa atau dosen untuk mengelola booking ruangan kampus.
                </p>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger py-2">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="font-size:.85rem;"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('register')); ?>" class="mt-2">
                <?php echo csrf_field(); ?>

                
                <div class="mb-3">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input id="name"
                           type="text"
                           name="name"
                           value="<?php echo e(old('name')); ?>"
                           required
                           autofocus
                           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Nama lengkap sesuai data kampus">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" style="font-size:.85rem;"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-3">
                    <label for="email" class="form-label">Email Kampus</label>
                    <input id="email"
                           type="email"
                           name="email"
                           value="<?php echo e(old('email')); ?>"
                           required
                           class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="nama@kampus.ac.id">
                </div>

                
                <div class="mb-3">
                    <label for="role" class="form-label">Role</label>
                    <select id="role"
                            name="role"
                            class="form-select <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required>
                        <option value="">-- Pilih Role --</option>
                        <option value="mahasiswa" <?php echo e(old('role')=='mahasiswa' ? 'selected' : ''); ?>>Mahasiswa</option>
                        <option value="dosen" <?php echo e(old('role')=='dosen' ? 'selected' : ''); ?>>Dosen</option>
                    </select>
                </div>

                <div class="row g-3">
                    
                    <div class="col-md-6">
                        <label for="password" class="form-label">Password</label>
                        <input id="password"
                               type="password"
                               name="password"
                               required
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Minimal 8 karakter">
                    </div>

                    
                    <div class="col-md-6">
                        <label for="password_confirmation" class="form-label">Konfirmasi Password</label>
                        <input id="password_confirmation"
                               type="password"
                               name="password_confirmation"
                               required
                               class="form-control"
                               placeholder="Ulangi password">
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center mt-4">
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-ghost">
                        Sudah punya akun? Login
                    </a>
                    <button type="submit" class="gradient-btn">
                        Daftar
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Ruangin\resources\views/auth/register.blade.php ENDPATH**/ ?>