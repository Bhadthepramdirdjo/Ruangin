/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./resources/**/*.{blade.php,js,vue,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
