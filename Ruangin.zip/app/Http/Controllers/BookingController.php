<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Ruangan;
use App\Services\GoogleCalendarService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class BookingController extends Controller
{
    public function listRuangan()
    {
        // Ambil semua ruangan dan kelompokkan berdasarkan tipe
        $ruanganByType = Ruangan::all()->groupBy('tipe');
        $allRuangans   = Ruangan::all();

        return view('booking.list_ruangan', compact('ruanganByType', 'allRuangans'));
    }

    public function create($id_ruangan)
    {
        $ruangan = Ruangan::findOrFail($id_ruangan);
        $user = Auth::user();
        
        // Validasi: Mahasiswa tidak boleh booking LAB
        if ($user->role === 'mahasiswa' && strtolower($ruangan->tipe) === 'lab') {
            return redirect()
                ->route('ruangan.list')
                ->with('error', 'Maaf, Anda (mahasiswa) tidak dapat booking ruangan tipe Lab. Lab hanya dapat di-booking oleh Dosen.');
        }
        
        return view('booking.create', compact('ruangan', 'user'));
    }

    public function store(Request $request)
    {
        // Validasi dasar
        $validated = $request->validate(
            [
                'ruangan_id'  => 'required|exists:ruangan,id',
                'tanggal'     => 'required|date|after_or_equal:today',
                'jam_mulai'   => 'required|date_format:H:i',
                'jumlah_sks'  => 'required|integer|min:1|max:12',
                'keperluan'   => 'required|string|max:500',
                'dokumen'     => 'required|file|mimes:pdf|max:5120', // max 5MB
            ],
            [
                'dokumen.required' => 'Lampiran surat peminjaman wajib diunggah.',
                'dokumen.mimes'    => 'Lampiran harus berupa file PDF.',
                'dokumen.max'      => 'Ukuran lampiran maksimal 5MB.',
                'jumlah_sks.required' => 'Pilih durasi SKS yang diinginkan.',
                'jumlah_sks.min'   => 'Durasi minimal 1 SKS (50 menit).',
                'jumlah_sks.max'   => 'Durasi maksimal 12 SKS.',
            ]
        );

        // Validasi role: Mahasiswa tidak boleh booking Lab
        $user = Auth::user();
        $ruangan = Ruangan::findOrFail($validated['ruangan_id']);
        
        if ($user->role === 'mahasiswa' && strtolower($ruangan->tipe) === 'lab') {
            return redirect()
                ->back()
                ->with('error', 'Maaf, Anda (mahasiswa) tidak dapat booking ruangan tipe Lab.');
        }

        // Validasi: Cek apakah tanggal adalah hari libur atau akhir pekan
        $calendarService = new GoogleCalendarService();
        if ($calendarService->isHolidayOrWeekend($validated['tanggal'])) {
            $carbonDate = Carbon::parse($validated['tanggal']);
            $dayName = $carbonDate->translatedFormat('l');
            return redirect()
                ->back()
                ->withInput()
                ->with('error', "Maaf, tanggal {$carbonDate->format('d/m/Y')} ({$dayName}) adalah hari libur, akhir pekan, atau tanggal merah. Booking tidak dapat dilakukan pada hari ini.");
        }

        // Validasi durasi SKS: jam_mulai + (jumlah_sks * 50 menit) tidak boleh melebihi jam 18:00
        $jamMulai = Carbon::createFromTimeString($validated['jam_mulai'] . ':00');
        $durationMinutes = $validated['jumlah_sks'] * 50;
        $jamSelesai = $jamMulai->copy()->addMinutes($durationMinutes);
        $jamOperasionalAkhir = Carbon::createFromFormat('H:i', '18:00');

        if ($jamSelesai->gt($jamOperasionalAkhir)) {
            $maxSks = floor(($jamOperasionalAkhir->diffInMinutes($jamMulai)) / 50);
            return redirect()
                ->back()
                ->withInput()
                ->with('error', "SKS yang Anda pilih melebihi batas jam operasional. Jam mulai {$validated['jam_mulai']} hanya dapat di-booking maksimal {$maxSks} SKS (" . ($maxSks * 50) . " menit).");
        }

        // Validasi: Cek konflik dengan booking yang sudah disetujui
        $existingBooking = Booking::where('ruangan_id', $validated['ruangan_id'])
            ->where('tanggal', $validated['tanggal'])
            ->where('status', 'disetujui')
            ->get();

        foreach ($existingBooking as $booking) {
            $existingJamMulai = Carbon::createFromTimeString($booking->jam_mulai);
            $existingJamSelesai = $existingJamMulai->copy()->addMinutes($booking->jumlah_sks * 50);

            // Cek overlap: jam_baru_mulai < jam_existing_selesai AND jam_existing_mulai < jam_baru_selesai
            if ($jamMulai->lt($existingJamSelesai) && $existingJamMulai->lt($jamSelesai)) {
                // Ada konflik
                return redirect()
                    ->back()
                    ->withInput()
                    ->with('error', 'Ruangan sudah dibooking pada jam ' . $booking->jam_mulai . ' (selama ' . $booking->jumlah_sks . ' SKS). Silakan pilih waktu yang lain.');
            }
        }

        $validated['user_id'] = Auth::id();

        // Simpan file dokumen (wajib ada karena rule "required")
        if ($request->hasFile('dokumen')) {
            $path = $request->file('dokumen')->store('dokumen', 'public');
            $validated['dokumen'] = $path;
        }

        $validated['status'] = 'pending';
        $validated['dibuat'] = Carbon::now();

        Booking::create($validated);

        return redirect()
            ->route('booking.history')
            ->with('success', 'Booking berhasil dibuat, menunggu persetujuan');
    }

    // ================== GET AVAILABLE SLOTS (API) ==================
    public function getAvailableSlots(Request $request)
    {
        $ruangan_id = $request->query('ruangan_id');
        $tanggal = $request->query('tanggal');

        if (!$ruangan_id || !$tanggal) {
            return response()->json(['error' => 'ruangan_id dan tanggal diperlukan'], 400);
        }

        // Ambil semua booking yang approved untuk ruangan dan tanggal ini
        $bookings = Booking::where('ruangan_id', $ruangan_id)
            ->where('tanggal', $tanggal)
            ->where('status', 'disetujui')
            ->get();

        $occupiedSlots = [];

        // Konversi semua occupied slots menjadi array
        foreach ($bookings as $booking) {
            $jamMulai = Carbon::createFromTimeString($booking->jam_mulai);
            $durationMinutes = $booking->jumlah_sks * 50;
            $jamSelesai = $jamMulai->copy()->addMinutes($durationMinutes);

            // Tambahkan setiap slot 50 menit yang occupied
            $current = $jamMulai->copy();
            while ($current->lt($jamSelesai)) {
                $occupiedSlots[] = $current->format('H:i');
                $current->addMinutes(50);
            }
        }

        return response()->json([
            'occupied_slots' => array_unique($occupiedSlots),
            'total_occupied' => count(array_unique($occupiedSlots))
        ])->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
          ->header('Pragma', 'no-cache')
          ->header('Expires', '0');
    }

    // ================== GET UNAVAILABLE DATES (HOLIDAYS + WEEKENDS) ==================
    public function getUnavailableDates(Request $request)
    {
        $startDate = $request->query('start_date');
        $endDate = $request->query('end_date');

        if (!$startDate || !$endDate) {
            return response()->json(['error' => 'start_date dan end_date diperlukan'], 400);
        }

        $calendarService = new GoogleCalendarService();
        $unavailableDates = $calendarService->getUnavailableDates($startDate, $endDate);

        return response()->json([
            'unavailable_dates' => $unavailableDates,
            'total_unavailable' => count($unavailableDates)
        ])->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
          ->header('Pragma', 'no-cache')
          ->header('Expires', '0');
    }

    public function myBookings()
    {
        $bookings = Booking::where('user_id', Auth::id())
            ->with('ruangan')
            ->orderBy('tanggal', 'desc')
            ->get();

        return view('booking.my_bookings', compact('bookings'));
    }

    public function history()
    {
        $bookings = Booking::where('user_id', Auth::id())
            ->with('ruangan')
            ->orderBy('tanggal', 'desc')
            ->get();

        return view('booking.history', compact('bookings'));
    }

    // ================== LIHAT DOKUMEN (LAMPIRAN) ==================
    public function showDokumen(Booking $booking)
    {
        // boleh diakses pemilik booking atau admin
        if (Auth::check() && $booking->user_id !== Auth::id() && auth()->user()->role !== 'admin') {
            abort(403);
        }

        if (!$booking->dokumen) {
            abort(404, 'Dokumen tidak tersedia.');
        }

        $disk = Storage::disk('public');

        if (!$disk->exists($booking->dokumen)) {
            abort(404, 'File dokumen tidak ditemukan di server.');
        }

        $fullPath = $disk->path($booking->dokumen);

        return response()->file($fullPath);
    }

    // ================== DOWNLOAD DOKUMEN ==================
    public function downloadDokumen(Booking $booking)
    {
        // boleh diakses pemilik booking atau admin
        if (Auth::check() && $booking->user_id !== Auth::id() && auth()->user()->role !== 'admin') {
            abort(403);
        }

        if (!$booking->dokumen) {
            abort(404, 'Dokumen tidak tersedia.');
        }

        $disk = Storage::disk('public');

        if (!$disk->exists($booking->dokumen)) {
            abort(404, 'File dokumen tidak ditemukan di server.');
        }

        $ext = pathinfo($booking->dokumen, PATHINFO_EXTENSION);

        $ruanganName = optional($booking->ruangan)->nama_ruang ?? 'Ruangan';
        $user        = $booking->user ?? null;
        $userName    = $user ? ($user->nama ?? $user->name ?? 'User') : 'User';

        $tanggal = $booking->tanggal
            ? Carbon::parse($booking->tanggal)->format('Ymd')
            : date('Ymd');

        $slugRuangan = preg_replace('/[^A-Za-z0-9\-]+/', '_', $ruanganName);
        $slugUser    = preg_replace('/[^A-Za-z0-9\-]+/', '_', $userName);

        $filename = "Booking_{$slugRuangan}_{$tanggal}_{$slugUser}." . $ext;

        return response()->download($disk->path($booking->dokumen), $filename);
    }
}
